"""Book catalog persistence package."""
